"use client"

import type React from "react"
import { useState } from "react"
import { Inter } from "next/font/google"
import "./globals.css"
import TikTokContentGenerator from "./page"
import SubscriptionPage from "./subscription/page"
import AuthPage from "./auth/signin/page"
import ProfilePage from "./profile/page"

const inter = Inter({ subsets: ["latin"] })

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const [currentPage, setCurrentPage] = useState<"home" | "subscription" | "auth" | "profile">("home")
  const [currentUser, setCurrentUser] = useState<any>(null)

  const navigateToSubscription = () => {
    setCurrentPage("subscription")
  }

  const navigateToAuth = () => {
    setCurrentPage("auth")
  }

  const navigateToProfile = () => {
    setCurrentPage("profile")
  }

  const navigateToHome = () => {
    setCurrentPage("home")
  }

  const handleLogout = () => {
    setCurrentUser(null)
    setCurrentPage("home")
  }

  const handleAuthSuccess = (user: any) => {
    setCurrentUser(user)
    setCurrentPage("home")
  }

  return (
    <html lang="en">
      <body className={inter.className}>
        {currentPage === "home" && (
          <TikTokContentGenerator
            user={currentUser}
            onNavigateToSubscription={navigateToSubscription}
            onNavigateToAuth={navigateToAuth}
            onNavigateToProfile={navigateToProfile}
            onLogout={handleLogout}
          />
        )}
        {currentPage === "subscription" && <SubscriptionPage onNavigateBack={navigateToHome} />}
        {currentPage === "auth" && <AuthPage onNavigateBack={navigateToHome} onAuthSuccess={handleAuthSuccess} />}
        {currentPage === "profile" && (
          <ProfilePage
            user={currentUser}
            onNavigateBack={navigateToHome}
            onNavigateToSubscription={navigateToSubscription}
          />
        )}
      </body>
    </html>
  )
}
