"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function generateContentIdeas(profile: {
  niche: string
  audience: string
  style: string
  experience: string
}) {
  try {
    // Use available API key or fallback to mock
    const apiKey = process.env.API_KEY || process.env.OPENAI_API_KEY

    if (apiKey) {
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Generate 5 highly creative and viral-worthy TikTok content ideas for a creator with this profile:

Niche: ${profile.niche}
Target Audience: ${profile.audience}
Content Style: ${profile.style}
Experience Level: ${profile.experience}

Requirements:
- Each idea should be unique and actionable
- Include specific hooks and concepts
- Consider current trends and viral potential
- Make them engaging for the target audience
- Provide clear execution steps

Format each idea as:
"[Title]: [Description] - [Hook/Angle]"

Make them creative, specific, and ready to execute.`,
      })

      return { success: true, ideas: text }
    } else {
      // Mock response for demo purposes
      const mockIdeas = `1. "${profile.niche} Secrets ${profile.audience} Love": Share insider tips with trending audio - Hook: "POV: You finally learn the ${profile.niche} hack everyone's been gatekeeping"

2. "My ${profile.niche} Glow-Up Journey": Document your transformation story - Hook: "This ${profile.niche} change literally saved my life"

3. "${profile.style} ${profile.niche} Content That Goes Viral": Meta-content about creation - Hook: "Why this ${profile.niche} format gets millions of views every time"

4. "Reacting to ${profile.niche} TikToks": Commentary with your expertise - Hook: "As a ${profile.experience} ${profile.niche} creator, this made me cringe"

5. "${profile.audience} vs ${profile.niche} Reality": Expectation vs reality format - Hook: "What ${profile.audience} think ${profile.niche} is like vs reality"`

      return { success: true, ideas: mockIdeas }
    }
  } catch (error) {
    console.error("Error generating content ideas:", error)

    // Fallback mock response
    const fallbackIdeas = `1. "Ultimate ${profile.niche} Guide": Comprehensive tutorial for ${profile.audience}
2. "${profile.style} ${profile.niche} Tips": Quick actionable advice
3. "Day in My ${profile.niche} Life": Behind-the-scenes content
4. "${profile.niche} Mistakes to Avoid": Educational content
5. "Trending ${profile.niche} Challenge": Participate in viral trends`

    return { success: true, ideas: fallbackIdeas }
  }
}

export async function generateTrendAnalysis(niche: string) {
  try {
    const apiKey = process.env.API_KEY || process.env.OPENAI_API_KEY

    if (apiKey) {
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Analyze current TikTok trends for the ${niche} niche. Provide:

1. Top 3 trending topics in this niche
2. Emerging trends to watch
3. Best hashtags to use
4. Content formats that are performing well
5. Timing recommendations

Keep it concise and actionable for creators.`,
      })

      return { success: true, analysis: text }
    } else {
      // Mock trend analysis
      const mockAnalysis = `Current ${niche} Trends:

1. Top Trending Topics:
   • Quick tutorials and how-tos
   • Behind-the-scenes content
   • Transformation videos

2. Emerging Trends:
   • AI-assisted content creation
   • Sustainable practices
   • Mental health awareness

3. Best Hashtags:
   • #${niche.toLowerCase()}tips
   • #${niche.toLowerCase()}hacks
   • #fyp #viral #trending

4. Performing Formats:
   • 15-30 second tutorials
   • Before/after comparisons
   • Reaction videos

5. Optimal Timing:
   • Peak hours: 6-9 PM
   • Best days: Tuesday-Thursday`

      return { success: true, analysis: mockAnalysis }
    }
  } catch (error) {
    console.error("Error generating trend analysis:", error)
    return { success: false, error: "Failed to analyze trends" }
  }
}

export async function generateCustomPrompt(prompt: string, userContext?: string) {
  try {
    const apiKey = process.env.API_KEY || process.env.OPENAI_API_KEY

    if (apiKey) {
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: `Create 3 unique TikTok content ideas based on this prompt: "${prompt}"

${userContext ? `Creator context: ${userContext}` : ""}

Make each idea:
- Viral-worthy and engaging
- Specific and actionable
- Include trending elements
- Provide clear execution steps

Format as numbered list with detailed descriptions.`,
      })

      return { success: true, ideas: text }
    } else {
      // Mock custom prompt response
      const mockIdeas = `1. "${prompt} Challenge": Create a trending challenge around your topic with catchy music and clear instructions

2. "POV: You're explaining ${prompt}": Educational storytelling format that makes complex topics accessible

3. "${prompt} but make it aesthetic": Visually appealing content with trending transitions and popular sounds`

      return { success: true, ideas: mockIdeas }
    }
  } catch (error) {
    console.error("Error generating custom ideas:", error)
    return { success: false, error: "Failed to generate custom ideas" }
  }
}
