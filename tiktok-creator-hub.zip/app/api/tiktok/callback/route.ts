import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { supabaseAdmin } from "@/lib/supabase"

const TIKTOK_CLIENT_KEY = process.env.TIKTOK_CLIENT_KEY!
const TIKTOK_CLIENT_SECRET = process.env.TIKTOK_CLIENT_SECRET!
const TIKTOK_REDIRECT_URI = process.env.NEXTAUTH_URL + "/api/tiktok/callback"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get("code")
  const state = searchParams.get("state")
  const error = searchParams.get("error")

  if (error) {
    return NextResponse.redirect(new URL("/profile?tiktok_error=" + error, request.url))
  }

  if (!code || !state) {
    return NextResponse.redirect(new URL("/profile?tiktok_error=missing_params", request.url))
  }

  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.redirect(new URL("/auth/signin", request.url))
  }

  try {
    // Verify CSRF state
    const { data: userProfile } = await supabaseAdmin
      .from("user_profiles")
      .select("tiktok_oauth_state")
      .eq("user_id", session.user.id)
      .single()

    if (userProfile?.tiktok_oauth_state !== state) {
      throw new Error("Invalid state parameter")
    }

    // Exchange code for access token
    const tokenResponse = await fetch("https://open-api.tiktok.com/oauth/access_token/", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_key: TIKTOK_CLIENT_KEY,
        client_secret: TIKTOK_CLIENT_SECRET,
        code: code,
        grant_type: "authorization_code",
        redirect_uri: TIKTOK_REDIRECT_URI,
      }),
    })

    const tokenData = await tokenResponse.json()

    if (tokenData.error) {
      throw new Error(tokenData.error_description || "Token exchange failed")
    }

    // Get user info from TikTok
    const userInfoResponse = await fetch("https://open-api.tiktok.com/user/info/", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        fields: [
          "open_id",
          "union_id",
          "avatar_url",
          "display_name",
          "username",
          "follower_count",
          "following_count",
          "likes_count",
          "video_count",
          "is_verified",
        ],
      }),
    })

    const userInfo = await userInfoResponse.json()

    if (userInfo.error) {
      throw new Error(userInfo.error.message || "Failed to get user info")
    }

    const tiktokUser = userInfo.data.user

    // Store TikTok connection in database
    await supabaseAdmin.from("tiktok_connections").upsert({
      user_id: session.user.id,
      tiktok_user_id: tiktokUser.open_id,
      username: tiktokUser.username,
      display_name: tiktokUser.display_name,
      follower_count: tiktokUser.follower_count,
      following_count: tiktokUser.following_count,
      likes_count: tiktokUser.likes_count,
      video_count: tiktokUser.video_count,
      is_verified: tiktokUser.is_verified,
      access_token: tokenData.access_token,
      refresh_token: tokenData.refresh_token,
      token_expires_at: new Date(Date.now() + tokenData.expires_in * 1000).toISOString(),
      profile_data: tiktokUser,
    })

    // Update user profile
    await supabaseAdmin
      .from("user_profiles")
      .update({
        tiktok_connected: true,
        tiktok_username: tiktokUser.username,
        tiktok_user_id: tiktokUser.open_id,
        tiktok_oauth_state: null, // Clear the state
      })
      .eq("user_id", session.user.id)

    return NextResponse.redirect(new URL("/profile?tiktok_success=true", request.url))
  } catch (error) {
    console.error("TikTok OAuth error:", error)
    return NextResponse.redirect(new URL("/profile?tiktok_error=connection_failed", request.url))
  }
}
