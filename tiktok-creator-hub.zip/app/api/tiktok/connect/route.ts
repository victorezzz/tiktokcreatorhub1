import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { supabaseAdmin } from "@/lib/supabase"

// TikTok OAuth configuration
const TIKTOK_CLIENT_KEY = process.env.TIKTOK_CLIENT_KEY!
const TIKTOK_CLIENT_SECRET = process.env.TIKTOK_CLIENT_SECRET!
const TIKTOK_REDIRECT_URI = process.env.NEXTAUTH_URL + "/api/tiktok/callback"

export async function GET(request: NextRequest) {
  const session = await getServerSession(authOptions)

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  // Generate TikTok OAuth URL
  const csrfState = Math.random().toString(36).substring(2, 15)

  // Store CSRF state in database for verification
  await supabaseAdmin.from("user_profiles").update({ tiktok_oauth_state: csrfState }).eq("user_id", session.user.id)

  const tiktokAuthUrl = new URL("https://www.tiktok.com/auth/authorize/")
  tiktokAuthUrl.searchParams.append("client_key", TIKTOK_CLIENT_KEY)
  tiktokAuthUrl.searchParams.append("scope", "user.info.basic,user.info.profile,user.info.stats,video.list")
  tiktokAuthUrl.searchParams.append("response_type", "code")
  tiktokAuthUrl.searchParams.append("redirect_uri", TIKTOK_REDIRECT_URI)
  tiktokAuthUrl.searchParams.append("state", csrfState)

  return NextResponse.json({ authUrl: tiktokAuthUrl.toString() })
}
