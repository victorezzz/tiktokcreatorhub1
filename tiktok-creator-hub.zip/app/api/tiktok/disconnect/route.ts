import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { supabaseAdmin } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Delete TikTok connection
    await supabaseAdmin.from("tiktok_connections").delete().eq("user_id", session.user.id)

    // Update user profile
    await supabaseAdmin
      .from("user_profiles")
      .update({
        tiktok_connected: false,
        tiktok_username: null,
        tiktok_user_id: null,
      })
      .eq("user_id", session.user.id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error disconnecting TikTok:", error)
    return NextResponse.json({ error: "Failed to disconnect TikTok" }, { status: 500 })
  }
}
