import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { supabaseAdmin } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  const session = await getServerSession(authOptions)

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Get user profile
    const { data: profile } = await supabaseAdmin
      .from("user_profiles")
      .select("*")
      .eq("user_id", session.user.id)
      .single()

    // Get TikTok connection if exists
    const { data: tiktokConnection } = await supabaseAdmin
      .from("tiktok_connections")
      .select("*")
      .eq("user_id", session.user.id)
      .single()

    // Get user analytics
    const { data: analytics } = await supabaseAdmin
      .from("user_analytics")
      .select("*")
      .eq("user_id", session.user.id)
      .single()

    return NextResponse.json({
      profile,
      tiktokConnection,
      analytics,
    })
  } catch (error) {
    console.error("Error fetching user profile:", error)
    return NextResponse.json({ error: "Failed to fetch profile" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  const session = await getServerSession(authOptions)

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { name, email } = body

    const { data, error } = await supabaseAdmin
      .from("user_profiles")
      .update({
        name,
        email,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", session.user.id)
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ profile: data })
  } catch (error) {
    console.error("Error updating user profile:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}
