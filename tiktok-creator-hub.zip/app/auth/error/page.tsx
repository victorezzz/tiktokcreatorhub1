"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Video, AlertCircle, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

export default function AuthErrorPage() {
  const router = useRouter()

  const getErrorMessage = () => {
    return "An unexpected error occurred. Please try again."
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Button
            onClick={() => router.push("/")}
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center">
              <Video className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">TikTok Creator Hub</h1>
          </div>
        </div>

        <Card className="border-0 shadow-2xl bg-[#111111] border border-gray-800">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
            <CardTitle className="text-2xl font-bold text-white">Authentication Error</CardTitle>
            <CardDescription className="text-gray-400">There was a problem signing you in</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 text-center">
            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
              <p className="text-red-400">{getErrorMessage()}</p>
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => router.push("/auth/signin")}
                className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
              >
                Try Again
              </Button>
              <Button
                onClick={() => router.push("/")}
                variant="outline"
                className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Back to Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
