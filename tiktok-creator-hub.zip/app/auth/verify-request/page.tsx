"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Video, Mail, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

export default function VerifyRequestPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Button
            onClick={() => router.push("/auth/signin")}
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Sign In
          </Button>
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center">
              <Video className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">TikTok Creator Hub</h1>
          </div>
        </div>

        <Card className="border-0 shadow-2xl bg-[#111111] border border-gray-800">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-white">Check Your Email</CardTitle>
            <CardDescription className="text-gray-400">
              We've sent you a magic link to sign in to your account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 text-center">
            <div className="space-y-2">
              <p className="text-gray-300">A sign in link has been sent to your email address.</p>
              <p className="text-sm text-gray-400">
                Click the link in the email to sign in. The link will expire in 24 hours.
              </p>
            </div>

            <div className="p-4 bg-[#1a1a1a] rounded-lg border border-gray-700">
              <h4 className="font-semibold text-white mb-2">Didn't receive the email?</h4>
              <ul className="text-sm text-gray-400 space-y-1 text-left">
                <li>• Check your spam/junk folder</li>
                <li>• Make sure you entered the correct email address</li>
                <li>• Wait a few minutes for the email to arrive</li>
              </ul>
            </div>

            <Button
              onClick={() => router.push("/auth/signin")}
              variant="outline"
              className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
