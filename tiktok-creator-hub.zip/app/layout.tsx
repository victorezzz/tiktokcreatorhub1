import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "TikTok Content Generator",
  description: "AI-powered TikTok content ideas generator",
    generator: 'v0.dev'
}

import ClientLayout from "./ClientLayout"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <ClientLayout>{children}</ClientLayout>
}


import './globals.css'