"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Sparkles,
  TrendingUp,
  Calendar,
  Lightbulb,
  Video,
  Hash,
  Users,
  Heart,
  Share2,
  Zap,
  Target,
  Camera,
  Music,
  LogIn,
  UserPlus,
  User,
  Settings,
  LogOut,
  Crown,
} from "lucide-react"

import { generateContentIdeas, generateCustomPrompt } from "./actions"

const contentCategories = [
  "Dance",
  "Comedy",
  "Educational",
  "Lifestyle",
  "Food",
  "Fashion",
  "Tech",
  "Travel",
  "Fitness",
  "DIY",
  "Pets",
  "Gaming",
]

const trendingHashtags = [
  "#fyp",
  "#viral",
  "#trending",
  "#foryou",
  "#tiktok",
  "#dance",
  "#comedy",
  "#lifestyle",
  "#food",
  "#fashion",
  "#diy",
  "#pets",
  "#gaming",
]

const contentIdeas = {
  dance: [
    "Learn a trending dance in 15 seconds",
    "Dance battle with your pet",
    "Teaching dance to grandparents",
    "Dance transition outfit change",
    "Recreate iconic music video dances",
  ],
  comedy: [
    "POV: You're the main character",
    "Expectation vs Reality scenarios",
    "Reacting to old photos/videos",
    "Impersonating different personalities",
    "Day in the life parodies",
  ],
  educational: [
    "Fun facts that blow your mind",
    "Life hacks everyone should know",
    "Quick language lessons",
    "Science experiments at home",
    "Historical events in 60 seconds",
  ],
  lifestyle: [
    "Morning routine that changed my life",
    "Room makeover on a budget",
    "Self-care Sunday essentials",
    "Productivity tips that actually work",
    "Minimalist living hacks",
  ],
  food: [
    "5-minute recipe challenges",
    "Food hacks that save money",
    "Trying viral food trends",
    "Cooking with only 3 ingredients",
    "Rating weird food combinations",
  ],
  fashion: [
    "Outfit of the day transitions",
    "Thrift flip transformations",
    "Styling one piece 5 ways",
    "Fashion trends through decades",
    "Closet organization hacks",
  ],
}

interface TikTokContentGeneratorProps {
  user?: any
  onNavigateToSubscription?: () => void
  onNavigateToAuth?: () => void
  onNavigateToProfile?: () => void
  onLogout?: () => void
}

export default function TikTokContentGenerator({
  user,
  onNavigateToSubscription,
  onNavigateToAuth,
  onNavigateToProfile,
  onLogout,
}: TikTokContentGeneratorProps) {
  const [selectedCategory, setSelectedCategory] = useState("")
  const [generatedIdea, setGeneratedIdea] = useState("")
  const [customPrompt, setCustomPrompt] = useState("")

  const [userProfile, setUserProfile] = useState({
    niche: "",
    audience: "",
    style: "",
    experience: "",
  })
  const [isGenerating, setIsGenerating] = useState(false)
  const [aiGeneratedIdeas, setAiGeneratedIdeas] = useState<string[]>([])
  const [personalizedSuggestions, setPersonalizedSuggestions] = useState<string[]>([])

  const generateIdea = () => {
    if (selectedCategory && contentIdeas[selectedCategory as keyof typeof contentIdeas]) {
      const ideas = contentIdeas[selectedCategory as keyof typeof contentIdeas]
      const randomIdea = ideas[Math.floor(Math.random() * ideas.length)]
      setGeneratedIdea(randomIdea)
    }
  }

  const generateCustomIdea = async () => {
    setIsGenerating(true)
    try {
      const result = await generateCustomPrompt(customPrompt)
      if (result && result.success) {
        setGeneratedIdea(result.ideas || "Error generating idea. Please try again.")
      } else {
        setGeneratedIdea("Error generating idea. Please try again.")
      }
    } catch (error) {
      console.error("Error generating custom idea:", error)
      setGeneratedIdea("Error generating idea. Please try again.")
    }
    setIsGenerating(false)
  }

  const generateAIIdea = async () => {
    setIsGenerating(true)
    try {
      const result = await generateContentIdeas({
        niche: userProfile.niche || selectedCategory,
        audience: userProfile.audience || "general",
        style: userProfile.style || "entertaining",
        experience: userProfile.experience || "beginner",
      })

      if (result && result.success) {
        const ideas = (result.ideas || "").split("\n").filter((line) => line.trim().length > 0)
        setAiGeneratedIdeas(ideas.length > 0 ? ideas : ["Error generating ideas. Please try again."])
      } else {
        setAiGeneratedIdeas(["Error generating ideas. Please try again."])
      }
    } catch (error) {
      console.error("Error generating AI ideas:", error)
      setAiGeneratedIdeas(["Error generating ideas. Please try again."])
    }
    setIsGenerating(false)
  }

  const generatePersonalizedContent = async () => {
    setIsGenerating(true)
    try {
      const result = await generateContentIdeas(userProfile)

      if (result && result.success) {
        const suggestions = (result.ideas || "").split("\n").filter((line) => line.trim().length > 0)
        setPersonalizedSuggestions(
          suggestions.length > 0 ? suggestions : ["Error generating personalized ideas. Please try again."],
        )
      } else {
        setPersonalizedSuggestions(["Error generating personalized ideas. Please try again."])
      }
    } catch (error) {
      console.error("Error generating personalized content:", error)
      setPersonalizedSuggestions(["Error generating personalized ideas. Please try again."])
    }
    if (personalizedSuggestions.length > 0) {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
    setIsGenerating(false)
  }

  const handleGetPremium = () => {
    if (onNavigateToSubscription) {
      onNavigateToSubscription()
    }
  }

  // Safely get current user with proper fallbacks
  const currentUser = user || null
  const userName = currentUser?.name || currentUser?.firstName || "User"
  const userEmail = currentUser?.email || ""
  const userAvatar = currentUser?.image || currentUser?.avatar || "/placeholder.svg"
  const isPremium = currentUser?.isPremium || false

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fadeInUp {
          animation: fadeInUp 0.6s ease-out forwards;
        }
      `}</style>
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center">
                <Video className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-white">TikTok Creator Hub</h1>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={handleGetPremium}
                className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg hover:shadow-purple-500/25 transition-all duration-300"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Get Premium
              </Button>

              {currentUser ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={userAvatar || "/placeholder.svg"} alt={userName} />
                        <AvatarFallback className="bg-gradient-to-r from-purple-600 to-purple-800 text-white">
                          {userName.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 bg-[#111111] border-gray-800" align="end" forceMount>
                    <div className="flex items-center justify-start gap-2 p-2">
                      <div className="flex flex-col space-y-1 leading-none">
                        <p className="font-medium text-white">{userName}</p>
                        <p className="w-[200px] truncate text-sm text-gray-400">{userEmail}</p>
                      </div>
                    </div>
                    <DropdownMenuSeparator className="bg-gray-800" />
                    <DropdownMenuItem
                      onClick={onNavigateToProfile}
                      className="text-gray-300 hover:bg-gray-800 hover:text-white cursor-pointer"
                    >
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-gray-300 hover:bg-gray-800 hover:text-white cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </DropdownMenuItem>
                    {isPremium && (
                      <DropdownMenuItem className="text-purple-400 hover:bg-gray-800 cursor-pointer">
                        <Crown className="mr-2 h-4 w-4" />
                        Premium Account
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator className="bg-gray-800" />
                    <DropdownMenuItem
                      onClick={onLogout}
                      className="text-red-400 hover:bg-gray-800 hover:text-red-300 cursor-pointer"
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      Log out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="flex items-center gap-2">
                  <Button
                    onClick={onNavigateToAuth}
                    variant="ghost"
                    className="text-gray-300 hover:text-white hover:bg-gray-800"
                  >
                    <LogIn className="w-4 h-4 mr-2" />
                    Sign In
                  </Button>
                  <Button
                    onClick={onNavigateToAuth}
                    className="bg-gradient-to-r from-gray-600 to-gray-800 hover:from-gray-700 hover:to-gray-900 text-white"
                  >
                    <UserPlus className="w-4 h-4 mr-2" />
                    Sign Up
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl font-bold mb-6 text-white">Generate Viral TikTok Content Ideas</h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Never run out of content ideas again. Get personalized suggestions, trending topics, and creative prompts
              to boost your TikTok presence.
            </p>
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              <div className="flex items-center gap-2 bg-[#111111] border border-gray-800 rounded-full px-4 py-2 shadow-sm bg-[rgba(80,33,121,1)]">
                <TrendingUp className="w-5 h-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-200">Trending Ideas</span>
              </div>
              <div className="flex items-center gap-2 bg-[#111111] border border-gray-800 rounded-full px-4 py-2 shadow-sm bg-[rgba(80,33,121,1)]">
                <Lightbulb className="w-5 h-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-200">Creative Prompts</span>
              </div>
              <div className="flex items-center gap-2 bg-[#111111] border border-gray-800 rounded-full px-4 py-2 shadow-sm bg-[rgba(80,33,121,1)]">
                <Hash className="w-5 h-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-200">Hashtag Generator</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Prominent AI Ideas Section - Appears at top when generated */}
      {personalizedSuggestions.length > 0 && (
        <section className="py-8 bg-[#111111] border-y border-gray-700">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-8">
                <div className="inline-flex items-center gap-3 bg-[#1a1a1a] rounded-full px-6 py-3 mb-4 border border-gray-600">
                  <Sparkles className="w-6 h-6 text-gray-400 animate-pulse" />
                  <span className="text-white font-bold text-lg">AI Ideas Generated!</span>
                  <Sparkles className="w-6 h-6 text-gray-400 animate-pulse" />
                </div>
                <h3 className="text-4xl font-bold text-white mb-2">Your Personalized Content Ideas</h3>
                <p className="text-gray-300 text-lg">Custom-crafted for your unique creator profile</p>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {personalizedSuggestions.map((idea, index) => (
                  <div
                    key={index}
                    className="bg-[#111111] border border-gray-800 rounded-xl p-6 shadow-2xl transform hover:scale-105 transition-all duration-300 border-l-gray-600 animate-fadeInUp hover:border-gray-400"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="flex items-start gap-3 mb-4">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white font-bold text-sm">{index + 1}</span>
                      </div>
                      <p className="font-semibold text-gray-200 leading-relaxed">{idea}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
                      >
                        <Heart className="w-4 h-4 mr-2" />
                        Save
                      </Button>
                      <Button size="sm" variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                        <Share2 className="w-4 h-4 mr-2" />
                        Share
                      </Button>
                      <Button size="sm" variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                        <Calendar className="w-4 h-4 mr-2" />
                        Schedule
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="text-center mt-8">
                <Button
                  onClick={() => setPersonalizedSuggestions([])}
                  variant="outline"
                  className="bg-[#111111]/50 border-gray-600/50 text-gray-300 hover:bg-[#111111]/30"
                >
                  Generate New Ideas
                </Button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* API Status Notice */}
      <section className="py-4">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-[#111111] border border-gray-800 rounded-lg p-4 text-center">
              <div className="flex items-center justify-center gap-2 text-gray-300">
                <Lightbulb className="w-5 h-5" />
                <span className="font-medium">AI-Powered Content Generation Active</span>
              </div>
              <p className="text-sm text-gray-400 mt-1">Your ideas are being generated by advanced AI technology</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="generator" className="max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-5 mb-8 bg-[#1a1a1a]">
              <TabsTrigger value="generator" className="flex items-center gap-2 bg-[#0a0a0a] bg-[rgba(26,26,26,1)]">
                <Sparkles className="w-4 h-4" />
                AI Generator
              </TabsTrigger>
              <TabsTrigger value="insights" className="flex items-center gap-2 bg-[#0a0a0a] bg-[rgba(26,26,26,1)]">
                <Target className="w-4 h-4" />
                AI Insights
              </TabsTrigger>
              <TabsTrigger value="trending" className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Trending
              </TabsTrigger>
              <TabsTrigger value="planner" className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Content Planner
              </TabsTrigger>
              <TabsTrigger value="tips" className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                Pro Tips
              </TabsTrigger>
            </TabsList>

            {/* Idea Generator Tab */}
            <TabsContent value="generator" className="space-y-8">
              {/* User Profile Setup */}
              <Card className="border-0 shadow-lg bg-[#111111] border border-purple-500/30">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-gray-200">
                    <Users className="w-5 h-5 text-blue-500" />
                    AI Creator Profile
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    Tell us about yourself for personalized AI-generated content ideas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 text-gray-200">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Your Niche</label>
                      <Select
                        value={userProfile.niche}
                        onValueChange={(value) => setUserProfile({ ...userProfile, niche: value })}
                      >
                        <SelectTrigger className="bg-[#1a1a1a] text-gray-200">
                          <SelectValue placeholder="Select your content niche" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#1a1a1a] text-gray-200">
                          {contentCategories.map((category) => (
                            <SelectItem key={category} value={category.toLowerCase()} className="hover:bg-gray-600">
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Target Audience</label>
                      <Select
                        value={userProfile.audience}
                        onValueChange={(value) => setUserProfile({ ...userProfile, audience: value })}
                      >
                        <SelectTrigger className="bg-[#1a1a1a] text-gray-200">
                          <SelectValue placeholder="Who do you create for?" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#1a1a1a] text-gray-200">
                          <SelectItem value="gen-z" className="hover:bg-gray-600">
                            Gen Z (16-24)
                          </SelectItem>
                          <SelectItem value="millennials" className="hover:bg-gray-600">
                            Millennials (25-40)
                          </SelectItem>
                          <SelectItem value="parents" className="hover:bg-gray-600">
                            Parents & Families
                          </SelectItem>
                          <SelectItem value="professionals" className="hover:bg-gray-600">
                            Young Professionals
                          </SelectItem>
                          <SelectItem value="students" className="hover:bg-gray-600">
                            Students
                          </SelectItem>
                          <SelectItem value="general" className="hover:bg-gray-600">
                            General Audience
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Content Style</label>
                      <Select
                        value={userProfile.style}
                        onValueChange={(value) => setUserProfile({ ...userProfile, style: value })}
                      >
                        <SelectTrigger className="bg-[#1a1a1a] text-gray-200">
                          <SelectValue placeholder="Your content style" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#1a1a1a] text-gray-200">
                          <SelectItem value="funny" className="hover:bg-gray-600">
                            Funny & Comedic
                          </SelectItem>
                          <SelectItem value="educational" className="hover:bg-gray-600">
                            Educational & Informative
                          </SelectItem>
                          <SelectItem value="inspirational" className="hover:bg-gray-600">
                            Inspirational & Motivational
                          </SelectItem>
                          <SelectItem value="trendy" className="hover:bg-gray-600">
                            Trendy & Pop Culture
                          </SelectItem>
                          <SelectItem value="authentic" className="hover:bg-gray-600">
                            Authentic & Personal
                          </SelectItem>
                          <SelectItem value="creative" className="hover:bg-gray-600">
                            Creative & Artistic
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Experience Level</label>
                      <Select
                        value={userProfile.experience}
                        onValueChange={(value) => setUserProfile({ ...userProfile, experience: value })}
                      >
                        <SelectTrigger className="bg-[#1a1a1a] text-gray-200">
                          <SelectValue placeholder="Your TikTok experience" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#1a1a1a] text-gray-200">
                          <SelectItem value="beginner" className="hover:bg-gray-600">
                            Beginner (0-1k followers)
                          </SelectItem>
                          <SelectItem value="growing" className="hover:bg-gray-600">
                            Growing (1k-10k followers)
                          </SelectItem>
                          <SelectItem value="established" className="hover:bg-gray-600">
                            Established (10k-100k followers)
                          </SelectItem>
                          <SelectItem value="influencer" className="hover:bg-gray-600">
                            Influencer (100k+ followers)
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button
                    onClick={generatePersonalizedContent}
                    className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 shadow-lg hover:shadow-purple-500/25 transition-all duration-300"
                    disabled={isGenerating || !userProfile.niche}
                  >
                    {isGenerating ? (
                      <>
                        <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        Generating AI Ideas...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Generate Personalized Ideas
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-2 gap-8">
                <Card className="border-0 shadow-lg bg-[#111111] border border-green-500/30">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-200">
                      <Zap className="w-5 h-5 text-green-500" />
                      Quick AI Generator
                    </CardTitle>
                    <CardDescription className="text-gray-300">Get instant AI-powered content ideas</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 text-gray-200">
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger className="bg-[#1a1a1a] text-gray-200 border-green-500/30">
                        <SelectValue placeholder="Choose a content category" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1a1a1a] text-gray-200">
                        {contentCategories.map((category) => (
                          <SelectItem key={category} value={category.toLowerCase()} className="hover:bg-gray-600">
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      onClick={generateAIIdea}
                      className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 shadow-lg hover:shadow-purple-500/25 transition-all duration-300"
                      disabled={!selectedCategory || isGenerating}
                    >
                      {isGenerating ? (
                        <>
                          <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          AI Thinking...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generate AI Ideas
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-[#111111] border border-blue-500/30">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-200">
                      <Lightbulb className="w-5 h-5 text-blue-500" />
                      Custom AI Prompt
                    </CardTitle>
                    <CardDescription className="text-gray-300">
                      Describe your vision and let AI create ideas
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 text-gray-200">
                    <Textarea
                      placeholder="Describe your content idea, mood, or theme... (e.g., 'funny morning routine for busy students')"
                      value={customPrompt}
                      onChange={(e) => setCustomPrompt(e.target.value)}
                      rows={3}
                      className="bg-[#1a1a1a] text-gray-200 border-blue-500/30"
                    />
                    <Button
                      onClick={generateCustomIdea}
                      className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 shadow-lg hover:shadow-purple-500/25 transition-all duration-300"
                      disabled={!customPrompt || isGenerating}
                    >
                      <Lightbulb className="w-4 h-4 mr-2" />
                      Create Custom AI Ideas
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* AI Generated Ideas Display */}
              {aiGeneratedIdeas.length > 0 && (
                <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-200">
                      <Zap className="w-5 h-5 text-yellow-500" />
                      AI Generated Ideas
                    </CardTitle>
                    <CardDescription className="text-gray-300">Fresh creative concepts powered by AI</CardDescription>
                  </CardHeader>
                  <CardContent className="text-gray-200">
                    <div className="space-y-3">
                      {aiGeneratedIdeas.map((idea, index) => (
                        <div key={index} className="p-4 bg-[#1a1a1a] rounded-lg border-l-gray-600">
                          <p className="font-medium text-gray-200">{idea}</p>
                          <div className="flex gap-2 mt-3">
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-gray-600 text-gray-300 hover:bg-gray-700"
                            >
                              <Heart className="w-4 h-4 mr-2" />
                              Save
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-gray-600 text-gray-300 hover:bg-gray-700"
                            >
                              <Share2 className="w-4 h-4 mr-2" />
                              Share
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-gray-600 text-gray-300 hover:bg-gray-700"
                            >
                              <Zap className="w-4 h-4 mr-2" />
                              Refine
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {generatedIdea && (
                <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-200">
                      <Video className="w-5 h-5 text-pink-500" />
                      Generated Idea
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-gray-200">
                    <p className="text-lg font-medium text-gray-200 mb-4">{generatedIdea}</p>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                        <Heart className="w-4 h-4 mr-2" />
                        Save Idea
                      </Button>
                      <Button size="sm" variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                        <Share2 className="w-4 h-4 mr-2" />
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Other tabs content remains the same... */}
            <TabsContent value="insights" className="space-y-8">
              <div className="text-center py-12 text-gray-500">
                <Target className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <h3 className="text-xl font-semibold mb-2">AI Insights Coming Soon</h3>
                <p>Advanced analytics and insights will be available here.</p>
              </div>
            </TabsContent>

            <TabsContent value="trending" className="space-y-8">
              <div className="grid md:grid-cols-2 gap-8">
                <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-200">
                      <Hash className="w-5 h-5 text-green-500" />
                      Trending Hashtags
                    </CardTitle>
                    <CardDescription className="text-gray-300">Popular hashtags to boost your reach</CardDescription>
                  </CardHeader>
                  <CardContent className="text-gray-200">
                    <div className="flex flex-wrap gap-2">
                      {trendingHashtags.map((hashtag) => (
                        <Badge key={hashtag} variant="secondary" className="cursor-pointer hover:bg-pink-100">
                          {hashtag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-200">
                      <Music className="w-5 h-5 text-purple-500" />
                      Trending Sounds
                    </CardTitle>
                    <CardDescription className="text-gray-300">Popular audio tracks for your videos</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3 text-gray-200">
                    {["Original Sound - @creator1", "Trending Beat #1", "Viral Audio Clip", "Popular Song Remix"].map(
                      (sound, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-[#1a1a1a] rounded-lg">
                          <span className="font-medium">{sound}</span>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            Use
                          </Button>
                        </div>
                      ),
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="planner" className="space-y-8">
              <div className="text-center py-12 text-gray-500">
                <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <h3 className="text-xl font-semibold mb-2">Content Planner Coming Soon</h3>
                <p>Schedule and organize your content calendar here.</p>
              </div>
            </TabsContent>

            <TabsContent value="tips" className="space-y-8">
              <div className="grid md:grid-cols-2 gap-8">
                <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-200">
                      <Camera className="w-5 h-5 text-orange-500" />
                      Video Creation Tips
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-gray-200">
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                      <p className="text-sm">Hook viewers in the first 3 seconds</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                      <p className="text-sm">Use high-quality lighting and audio</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                      <p className="text-sm">Keep your videos short and engaging</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-gray-200">
                      <Target className="w-5 h-5 text-blue-500" />
                      Engagement Strategies
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-gray-200">
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <p className="text-sm">Respond to comments and messages promptly</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <p className="text-sm">Ask questions to encourage interaction</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <p className="text-sm">Run contests and giveaways to boost engagement</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0a0a0a] border-t border-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center">
                <Video className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white">TikTok Creator Hub</h3>
            </div>
            <p className="text-gray-400 mb-6">Empowering creators with endless content possibilities</p>
            <div className="flex justify-center gap-6 text-sm text-gray-400">
              <a href="#" className="hover:text-gray-400 transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="hover:text-gray-400 transition-colors">
                Terms of Service
              </a>
              <a href="#" className="hover:text-gray-400 transition-colors">
                Contact
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
