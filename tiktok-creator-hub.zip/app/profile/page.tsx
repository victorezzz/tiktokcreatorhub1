"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Video,
  ArrowLeft,
  Crown,
  Settings,
  Heart,
  Calendar,
  TrendingUp,
  Users,
  ExternalLink,
  CheckCircle,
  Music,
} from "lucide-react"

interface ProfilePageProps {
  user: any
  onNavigateBack?: () => void
  onNavigateToSubscription?: () => void
}

export default function ProfilePage({ user, onNavigateBack, onNavigateToSubscription }: ProfilePageProps) {
  const [isConnectingTikTok, setIsConnectingTikTok] = useState(false)
  const [tiktokConnected, setTiktokConnected] = useState(user?.tiktokConnected || false)
  const [tiktokProfile, setTiktokProfile] = useState(
    user?.tiktokConnected
      ? {
          username: "@creativecreator",
          followers: "125.4K",
          following: "892",
          likes: "2.1M",
          verified: true,
        }
      : null,
  )

  const handleGoBack = () => {
    if (onNavigateBack) {
      onNavigateBack()
    }
  }

  const handleConnectTikTok = async () => {
    setIsConnectingTikTok(true)

    // Simulate TikTok OAuth connection
    setTimeout(() => {
      setTiktokConnected(true)
      setTiktokProfile({
        username: "@creativecreator",
        followers: "125.4K",
        following: "892",
        likes: "2.1M",
        verified: true,
      })
      setIsConnectingTikTok(false)
    }, 2000)
  }

  const handleDisconnectTikTok = () => {
    setTiktokConnected(false)
    setTiktokProfile(null)
  }

  const savedIdeas = [
    "POV: You're explaining quantum physics to your pet",
    "Day in the life of a productivity guru who's actually chaotic",
    "Rating viral TikTok trends as a Gen Z boomer",
  ]

  const stats = {
    ideasGenerated: 47,
    ideasSaved: 12,
    contentScheduled: 8,
    engagementBoost: "+23%",
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button onClick={handleGoBack} variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-white">TikTok Creator Hub</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {!user?.isPremium && (
                <Button
                  onClick={onNavigateToSubscription}
                  className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade to Premium
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Profile Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto space-y-8">
            {/* Profile Header */}
            <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
              <CardContent className="p-8">
                <div className="flex items-start gap-6">
                  <Avatar className="w-20 h-20">
                    <AvatarImage src={user?.avatar || "/placeholder.svg"} alt={user?.firstName} />
                    <AvatarFallback className="bg-gradient-to-r from-purple-600 to-purple-800 text-white text-xl">
                      {user?.firstName?.[0]}
                      {user?.lastName?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h2 className="text-2xl font-bold text-white">
                        {user?.firstName} {user?.lastName}
                      </h2>
                      {user?.isPremium && (
                        <Badge className="bg-gradient-to-r from-purple-600 to-purple-800 text-white">
                          <Crown className="w-3 h-3 mr-1" />
                          Premium
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-400 mb-4">{user?.email}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-300">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>Joined December 2024</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-4 h-4" />
                        <span>{stats.ideasGenerated} ideas generated</span>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                    <Settings className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* TikTok Connection */}
            <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Music className="w-5 h-5 text-pink-500" />
                  TikTok Account
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Connect your TikTok account to get personalized insights and analytics
                </CardDescription>
              </CardHeader>
              <CardContent>
                {tiktokConnected && tiktokProfile ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg border border-green-500/30">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-red-500 rounded-full flex items-center justify-center">
                          <Music className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-white">{tiktokProfile.username}</h3>
                            {tiktokProfile.verified && <CheckCircle className="w-4 h-4 text-blue-500" />}
                          </div>
                          <p className="text-gray-400 text-sm">Connected successfully</p>
                        </div>
                      </div>
                      <Button
                        onClick={handleDisconnectTikTok}
                        variant="outline"
                        size="sm"
                        className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                      >
                        Disconnect
                      </Button>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center p-4 bg-[#1a1a1a] rounded-lg">
                        <div className="text-2xl font-bold text-white">{tiktokProfile.followers}</div>
                        <div className="text-gray-400 text-sm">Followers</div>
                      </div>
                      <div className="text-center p-4 bg-[#1a1a1a] rounded-lg">
                        <div className="text-2xl font-bold text-white">{tiktokProfile.following}</div>
                        <div className="text-gray-400 text-sm">Following</div>
                      </div>
                      <div className="text-center p-4 bg-[#1a1a1a] rounded-lg">
                        <div className="text-2xl font-bold text-white">{tiktokProfile.likes}</div>
                        <div className="text-gray-400 text-sm">Likes</div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Music className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-white font-semibold mb-2">Connect Your TikTok Account</h3>
                    <p className="text-gray-400 mb-6 max-w-md mx-auto">
                      Link your TikTok account to get personalized content suggestions, track your performance, and
                      optimize your content strategy.
                    </p>
                    <Button
                      onClick={handleConnectTikTok}
                      disabled={isConnectingTikTok}
                      className="bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white"
                    >
                      {isConnectingTikTok ? (
                        <>
                          <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Connecting...
                        </>
                      ) : (
                        <>
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Connect TikTok Account
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Stats Overview */}
            <div className="grid md:grid-cols-4 gap-6">
              <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full flex items-center justify-center mx-auto mb-3">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stats.ideasGenerated}</div>
                  <div className="text-gray-400 text-sm">Ideas Generated</div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-600 to-green-800 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Heart className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stats.ideasSaved}</div>
                  <div className="text-gray-400 text-sm">Ideas Saved</div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-800 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Calendar className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stats.contentScheduled}</div>
                  <div className="text-gray-400 text-sm">Content Scheduled</div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-orange-600 to-orange-800 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stats.engagementBoost}</div>
                  <div className="text-gray-400 text-sm">Engagement Boost</div>
                </CardContent>
              </Card>
            </div>

            {/* Saved Ideas */}
            <Card className="border-0 shadow-lg bg-[#111111] border border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Heart className="w-5 h-5 text-red-500" />
                  Saved Ideas
                </CardTitle>
                <CardDescription className="text-gray-400">Your favorite content ideas for future use</CardDescription>
              </CardHeader>
              <CardContent>
                {savedIdeas.length > 0 ? (
                  <div className="space-y-3">
                    {savedIdeas.map((idea, index) => (
                      <div key={index} className="p-4 bg-[#1a1a1a] rounded-lg border border-gray-700">
                        <p className="text-white font-medium mb-2">{idea}</p>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            <Calendar className="w-4 h-4 mr-2" />
                            Schedule
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Use Now
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Heart className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No saved ideas yet. Start generating content to save your favorites!</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Premium Upgrade CTA */}
            {!user?.isPremium && (
              <Card className="border-0 shadow-lg bg-gradient-to-r from-purple-600/10 to-purple-800/10 border border-purple-500/30">
                <CardContent className="p-8 text-center bg-[rgba(26,26,26,1)]">
                  <Crown className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-white mb-2">Unlock Premium Features</h3>
                  <p className="text-gray-300 mb-6 max-w-md mx-auto">
                    Get unlimited AI ideas, advanced analytics, and priority support to supercharge your TikTok growth.
                  </p>
                  <Button
                    onClick={onNavigateToSubscription}
                    className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white px-8 py-3"
                  >
                    <Crown className="w-5 h-5 mr-2" />
                    Upgrade to Premium
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}
