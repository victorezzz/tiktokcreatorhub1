"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Sparkles,
  Video,
  Crown,
  Zap,
  TrendingUp,
  Users,
  Calendar,
  ArrowLeft,
  Star,
  Infinity,
  Shield,
  Headphones,
} from "lucide-react"

interface SubscriptionPageProps {
  onNavigateBack?: () => void
}

export default function SubscriptionPage({ onNavigateBack }: SubscriptionPageProps) {
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("monthly")

  const handleGoBack = () => {
    if (onNavigateBack) {
      onNavigateBack()
    }
  }

  const plans = {
    monthly: {
      price: 19,
      period: "month",
      savings: null,
    },
    yearly: {
      price: 149,
      period: "year",
      savings: "35% OFF",
    },
  }

  const features = [
    {
      icon: <Infinity className="w-5 h-5" />,
      title: "Unlimited AI Content Ideas",
      description: "Generate unlimited personalized TikTok content ideas with advanced AI",
    },
    {
      icon: <TrendingUp className="w-5 h-5" />,
      title: "Advanced Trend Analysis",
      description: "Real-time trend analysis and predictions powered by AI algorithms",
    },
    {
      icon: <Users className="w-5 h-5" />,
      title: "Audience Insights Pro",
      description: "Deep audience analytics and engagement optimization recommendations",
    },
    {
      icon: <Calendar className="w-5 h-5" />,
      title: "Content Calendar & Scheduling",
      description: "Plan, schedule, and manage your content with our advanced calendar",
    },
    {
      icon: <Zap className="w-5 h-5" />,
      title: "Priority AI Processing",
      description: "Skip the queue with lightning-fast AI content generation",
    },
    {
      icon: <Star className="w-5 h-5" />,
      title: "Premium Templates",
      description: "Access to exclusive content templates and viral formats",
    },
    {
      icon: <Shield className="w-5 h-5" />,
      title: "Advanced Analytics",
      description: "Track performance, ROI, and growth metrics for your content",
    },
    {
      icon: <Headphones className="w-5 h-5" />,
      title: "Priority Support",
      description: "24/7 premium support with dedicated account manager",
    },
  ]

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button onClick={handleGoBack} variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-white">TikTok Creator Hub</h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600/20 to-purple-800/20 border border-purple-500/30 rounded-full px-4 py-2 mb-6">
              <Crown className="w-5 h-5 text-purple-400" />
              <span className="text-purple-300 font-medium">Premium Membership</span>
            </div>
            <h2 className="text-5xl font-bold mb-6 text-white">Unlock Your Creative Potential</h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Join thousands of creators who've supercharged their TikTok success with our premium AI-powered tools and
              insights.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Toggle */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="flex items-center justify-center mb-12">
              <div className="bg-[#111111] border border-gray-800 rounded-full p-1 flex">
                <button
                  onClick={() => setSelectedPlan("monthly")}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                    selectedPlan === "monthly"
                      ? "bg-gradient-to-r from-purple-600 to-purple-800 text-white shadow-lg"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  Monthly
                </button>
                <button
                  onClick={() => setSelectedPlan("yearly")}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-300 relative ${
                    selectedPlan === "yearly"
                      ? "bg-gradient-to-r from-purple-600 to-purple-800 text-white shadow-lg"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  Yearly
                  {plans.yearly.savings && (
                    <Badge className="absolute -top-2 -right-2 bg-green-500 text-white px-2 py-1 text-xs tracking-normal font-bold leading-[0.5rem]">
                      {plans.yearly.savings}
                    </Badge>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Card */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <Card className="border-0 shadow-2xl bg-[#111111] border border-purple-500/30 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-purple-800/10"></div>
              <CardHeader className="text-center relative z-10">
                <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full px-4 py-2 mb-4 mx-auto">
                  <Crown className="w-4 h-4 text-white" />
                  <span className="text-white font-medium text-sm">Premium Plan</span>
                </div>
                <CardTitle className="text-4xl font-bold text-white mb-2">
                  ${plans[selectedPlan].price}
                  <span className="text-lg text-gray-400 font-normal">/{plans[selectedPlan].period}</span>
                </CardTitle>
                {selectedPlan === "yearly" && (
                  <p className="text-green-400 font-medium">Save $79 per year compared to monthly billing</p>
                )}
                <CardDescription className="text-gray-300 text-lg mt-4">
                  Everything you need to dominate TikTok with AI-powered content creation
                </CardDescription>
              </CardHeader>
              <CardContent className="relative z-10">
                <Button className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white text-lg py-6 mb-8 shadow-lg hover:shadow-purple-500/25 transition-all duration-300">
                  <Sparkles className="w-5 h-5 mr-2" />
                  Start Your Premium Journey
                </Button>

                <div className="space-y-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full flex items-center justify-center flex-shrink-0">
                        {feature.icon}
                      </div>
                      <div>
                        <h4 className="font-semibold text-white mb-1">{feature.title}</h4>
                        <p className="text-gray-400 text-sm">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-white mb-4">Why Creators Choose Premium</h3>
              <p className="text-gray-300 text-lg">
                Join the success stories of creators who've transformed their TikTok presence
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="bg-[#111111] border border-gray-800 text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-2xl font-bold text-white mb-2">3x Faster Growth</h4>
                  <p className="text-gray-400">
                    Premium users see 3x faster follower growth with AI-optimized content strategies
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border border-gray-800 text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-2xl font-bold text-white mb-2">10x More Ideas</h4>
                  <p className="text-gray-400">
                    Generate unlimited content ideas and never run out of creative inspiration
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border border-gray-800 text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Star className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-2xl font-bold text-white mb-2">Higher Engagement</h4>
                  <p className="text-gray-400">AI-optimized content leads to 5x higher engagement rates on average</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      

      {/* FAQ Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold text-white text-center mb-12">Frequently Asked Questions</h3>

            <div className="space-y-6">
              <Card className="bg-[#111111] border border-gray-800">
                <CardContent className="p-6">
                  <h4 className="text-white font-semibold mb-2">Can I cancel anytime?</h4>
                  <p className="text-gray-400">
                    Yes, you can cancel your subscription at any time. No long-term commitments or cancellation fees.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border border-gray-800">
                <CardContent className="p-6">
                  <h4 className="text-white font-semibold mb-2">Do you offer a free trial?</h4>
                  <p className="text-gray-400">
                    We offer a 7-day free trial for new users to experience all premium features before committing.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border border-gray-800">
                <CardContent className="p-6">
                  <h4 className="text-white font-semibold mb-2">What payment methods do you accept?</h4>
                  <p className="text-gray-400">
                    We accept all major credit cards, PayPal, and other secure payment methods.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border border-gray-800">
                
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 bg-gradient-to-r from-purple-600/10 to-purple-800/10 border-y border-purple-500/20">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h3 className="text-3xl font-bold text-white mb-4">Ready to Transform Your TikTok?</h3>
            <p className="text-gray-300 text-lg mb-8">
              Join thousands of creators who've already unlocked their potential with our premium AI tools.
            </p>
            <Button className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white text-lg px-8 py-4 shadow-lg hover:shadow-purple-500/25 transition-all duration-300">
              <Crown className="w-5 h-5 mr-2" />
              Start Your Premium Journey Now
            </Button>
            <p className="text-gray-400 text-sm mt-4">
              7-day free trial • Cancel anytime • Fast AI suport

            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0a0a0a] border-t border-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center">
                <Video className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white">TikTok Creator Hub</h3>
            </div>
            <p className="text-gray-400 mb-6">Empowering creators with endless content possibilities</p>
            <div className="flex justify-center gap-6 text-sm text-gray-400">
              <a href="#" className="hover:text-gray-400 transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="hover:text-gray-400 transition-colors">
                Terms of Service
              </a>
              <a href="#" className="hover:text-gray-400 transition-colors">
                Contact
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
