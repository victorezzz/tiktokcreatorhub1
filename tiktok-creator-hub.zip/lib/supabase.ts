import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Server-side client with service role key
export const supabaseAdmin = createClient(supabaseUrl, process.env.SUPABASE_SERVICE_ROLE_KEY!)

// Database types
export interface UserProfile {
  id: string
  user_id: string
  email: string
  name?: string
  avatar_url?: string
  provider?: string
  is_premium: boolean
  tiktok_connected: boolean
  tiktok_username?: string
  tiktok_user_id?: string
  tiktok_data?: any
  email_verified: boolean
  created_at: string
  updated_at: string
}

export interface ContentIdea {
  id: string
  user_id: string
  title: string
  description?: string
  category?: string
  tags?: string[]
  is_saved: boolean
  is_scheduled: boolean
  scheduled_date?: string
  created_at: string
}

export interface TikTokConnection {
  id: string
  user_id: string
  tiktok_user_id: string
  username: string
  display_name?: string
  follower_count?: number
  following_count?: number
  likes_count?: number
  video_count?: number
  is_verified: boolean
  access_token: string
  refresh_token?: string
  token_expires_at?: string
  profile_data?: any
  connected_at: string
  last_synced: string
}
